

package mysqlcon;

import java.sql.*  ;
public class MySQLcon {

    
   
    public static void main(String[] args)  {
      
        try{
        
        Connection myCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/server_room","root","developer999");
        
        Statement stm = myCon.createStatement();
        
        
        ResultSet rs = stm.executeQuery("SELECT * FROM server_room.users  ");
         while(rs.next()){
             String name =rs.getString("name");
             
             System.out.println( "Lidhja me databazen u realizua me sukses, emrat e perdoruesve jane :" + name);
             }
        
        
        
        
        
        }
        
      catch ( Exception exc)  {
     exc.printStackTrace();
      }
        
        
    
        
    }
    
}

